//
//  ContactSvc.h
//  ContactMgr
//
//  Created by A Student on 5/25/14.
//  Copyright (c) 2014 msse650. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Contact.h"

@protocol ContactSvc <NSObject>

- (Contact *) createContact: (Contact *) contact;
- (NSMutableArray *) retrieveAllContacts;
- (Contact *) updateContact: (Contact *) contact;
- (Contact *) deleteContact: (Contact *) contact;

@end
