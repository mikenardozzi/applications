//
//  ContactMgrViewController.m
//  ContactMgr
//
//  Created by A Student on 5/25/14.
//  Copyright (c) 2014 msse650. All rights reserved.
//

#import "ContactMgrViewController.h"
#import "Contact.h"
#import "ContactSvcCache.h"

@interface ContactMgrViewController ()

@end

@implementation ContactMgrViewController

ContactSvcCache *contactSvc = nil;



- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    contactSvc = [[ContactSvcCache alloc] init];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Return the number of contacts
- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    return [[contactSvc retrieveAllContacts] count];
}

// Return the table cell for a paricular row (index)
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    UITableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:simpleTableIdentifier];
    }
    Contact *contact = [[contactSvc retrieveAllContacts]
                        objectAtIndex:indexPath.row];
    cell.textLabel.text = [contact description];
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    return cell;
}

// Save Contact
- (IBAction)saveContact:(id)sender {
    NSLog(@"saveContact: entering");
    
    [self.view endEditing:YES];
    
    Contact *contact = [[Contact alloc] init];
    contact.name = _name.text;
    contact.phone = _phone.text;
    contact.email = _email.text;
    [contactSvc createContact:contact];
    
    [self.tableView reloadData];
    NSLog(@"saveContact: contact saved");}

// Delete Contact
- (IBAction)deleteContact:(id)sender {
    NSLog(@"deleteContact");
    
    [self.view endEditing:YES];}
@end
