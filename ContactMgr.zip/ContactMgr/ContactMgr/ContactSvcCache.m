//
//  ContactSvcCache.m
//  ContactMgr
//
//  Created by A Student on 5/25/14.
//  Copyright (c) 2014 msse650. All rights reserved.
//

#import "ContactSvcCache.h"

@implementation ContactSvcCache

NSMutableArray *contacts = nil;

- (id) init {
    if (self = [super init]) {
        contacts = [NSMutableArray array];
        return self;
    }
    return nil;
}
- (Contact *) createContact: (Contact *) contact {
    [contacts addObject: contact];
    return contact;
}
- (NSMutableArray *) retrieveAllContacts {
    return contacts;
}
- (Contact *) updateContact: (Contact *) contact {
    return contact;
}
- (Contact *) deleteContact: (Contact *) contact {
    return contact;
}
@end
