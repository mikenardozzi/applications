//
//  ContactSvcCache.h
//  ContactMgr
//
//  Created by A Student on 5/25/14.
//  Copyright (c) 2014 msse650. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ContactSvc.h"

@interface ContactSvcCache : NSObject <ContactSvc>

@end
